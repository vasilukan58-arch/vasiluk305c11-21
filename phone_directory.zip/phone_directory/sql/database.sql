-- Полный скрипт создания базы данных
CREATE DATABASE IF NOT EXISTS phone_directory;
USE phone_directory;

-- Таблицы и индексы...