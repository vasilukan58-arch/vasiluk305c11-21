<?php
require_once 'config.php';

// Проверка авторизации
$isLoggedIn = isset($_SESSION['user_id']);
$userName = $isLoggedIn ? $_SESSION['username'] : '';
$canSearch = $isLoggedIn ? $_SESSION['can_search'] : false;
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Телефонный справочник</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #ffe6e6 0%, #ffd6e7 50%, #ffe6f0 100%);
            color: #5a3d5c;
            line-height: 1.6;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            padding: 20px 0;
            margin-bottom: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(255, 182, 193, 0.3);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        
        .logo {
            font-size: 28px;
            font-weight: bold;
            color: #d94b7e;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        }
        
        nav ul {
            display: flex;
            list-style: none;
            gap: 20px;
        }
        
        nav ul li a {
            color: #5a3d5c;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        nav ul li a:hover {
            background: #ffb6c1;
            color: white;
            transform: translateY(-2px);
        }
        
        .page {
            display: none;
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(255, 182, 193, 0.2);
            margin-bottom: 30px;
            backdrop-filter: blur(10px);
        }
        
        .active {
            display: block;
            animation: fadeIn 0.5s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        h1, h2 {
            margin-bottom: 20px;
            color: #d94b7e;
        }
        
        .search-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #5a3d5c;
        }
        
        input, select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ffd6e7;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.8);
            transition: all 0.3s ease;
        }
        
        input:focus, select:focus {
            outline: none;
            border-color: #ffb6c1;
            box-shadow: 0 0 10px rgba(255, 182, 193, 0.3);
        }
        
        button {
            background: linear-gradient(135deg, #ffb6c1, #d94b7e);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            margin: 5px;
        }
        
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(217, 75, 126, 0.4);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(255, 182, 193, 0.2);
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ffd6e7;
        }
        
        th {
            background: linear-gradient(135deg, #ffb6c1, #d94b7e);
            color: white;
            font-weight: 600;
        }
        
        tr:hover {
            background: rgba(255, 182, 193, 0.1);
        }
        
        .departments-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .department-card {
            background: linear-gradient(135deg, #ffffff, #fff5f7);
            padding: 25px;
            border-radius: 15px;
            border-left: 5px solid #ffb6c1;
            box-shadow: 0 5px 15px rgba(255, 182, 193, 0.2);
            transition: transform 0.3s ease;
        }
        
        .department-card:hover {
            transform: translateY(-5px);
        }
        
        .login-form {
            max-width: 400px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(255, 182, 193, 0.3);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            background: linear-gradient(135deg, #ffd6e7, #ffb6c1);
            padding: 15px 20px;
            border-radius: 25px;
            margin-top: 20px;
            color: #5a3d5c;
        }
        
        footer {
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            color: #d94b7e;
        }
        
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 10px;
            text-align: center;
        }
        
        .error {
            background: #ffe6e6;
            color: #d94b7e;
            border: 1px solid #ffb6c1;
        }
        
        .success {
            background: #e6ffe6;
            color: #5a3d5c;
            border: 1px solid #b6ffc1;
        }
    </style>
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">🌸 Телефонный справочник</div>
            <nav>
                <ul>
                    <li><a href="#" onclick="showPage('home')">Главная</a></li>
                    <li><a href="#" onclick="showPage('departments')">Отделы</a></li>
                    <?php if ($isLoggedIn && $canSearch): ?>
                    <li><a href="#" onclick="showPage('search')">Поиск</a></li>
                    <?php endif; ?>
                    <?php if (!$isLoggedIn): ?>
                    <li><a href="#" onclick="showPage('login')">Вход</a></li>
                    <?php else: ?>
                    <li><a href="logout.php">Выход</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <!-- Главная страница -->
        <div id="home" class="page active">
            <h1>🌸 Добро пожаловать в телефонный справочник</h1>
            <p>Наша организация специализируется на разработке программного обеспечения и IT-консалтинге. Мы работаем на рынке более 15 лет и имеем репутацию надежного партнера.</p>
            
            <h2>О компании</h2>
            <p>Мы - команда профессионалов, объединенных общей целью создания качественных IT-решений для бизнеса. Наш коллектив состоит из более чем 200 специалистов в различных областях информационных технологий.</p>
            
            <h2>Наши ценности</h2>
            <ul style="margin-left: 20px; margin-bottom: 20px;">
                <li>Качество и надежность предоставляемых решений</li>
                <li>Инновационный подход к решению задач</li>
                <li>Клиентоориентированность и гибкость</li>
                <li>Профессиональное развитие сотрудников</li>
            </ul>
            
            <?php if ($isLoggedIn): ?>
            <div class="user-info">
                <strong>Вы вошли как:</strong> <?php echo htmlspecialchars($userName); ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Страница отделов -->
        <div id="departments" class="page">
            <h1>🌸 Структура организации</h1>
            <p>Наша компания состоит из нескольких ключевых отделов, каждый из которых выполняет важные функции в достижении общих целей.</p>
            
            <div class="departments-grid">
                <?php
                $db = getDB();
                $stmt = $db->query("
                    SELECT d.*, e.last_name, e.first_name, e.middle_name 
                    FROM departments d 
                    LEFT JOIN employees e ON d.director_id = e.id
                ");
                $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($departments as $dept): 
                ?>
                <div class="department-card">
                    <h3><?php echo htmlspecialchars($dept['name']); ?></h3>
                    <?php if ($dept['last_name']): ?>
                    <p><strong>Руководитель:</strong> <?php echo htmlspecialchars($dept['last_name'] . ' ' . $dept['first_name'] . ' ' . $dept['middle_name']); ?></p>
                    <?php endif; ?>
                    <p><strong>Направление деятельности:</strong> <?php echo htmlspecialchars($dept['description']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Страница поиска -->
        <?php if ($isLoggedIn && $canSearch): ?>
        <div id="search" class="page">
            <h1>🌸 Поиск сотрудников</h1>
            
            <form class="search-form" method="POST" action="search.php">
                <div class="form-group">
                    <label for="lastName">Фамилия:</label>
                    <input type="text" id="lastName" name="lastName" placeholder="Введите фамилию">
                </div>
                
                <div class="form-group">
                    <label for="firstName">Имя:</label>
                    <input type="text" id="firstName" name="firstName" placeholder="Введите имя">
                </div>
                
                <div class="form-group">
                    <label for="department">Отдел:</label>
                    <select id="department" name="department">
                        <option value="">Все отделы</option>
                        <?php
                        $stmt = $db->query("SELECT id, name FROM departments");
                        $depts = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($depts as $dept): 
                        ?>
                        <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="position">Должность:</label>
                    <input type="text" id="position" name="position" placeholder="Введите должность">
                </div>
                
                <div class="form-group">
                    <label for="room">Кабинет:</label>
                    <input type="text" id="room" name="room" placeholder="Номер кабинета">
                </div>
                
                <div class="form-group">
                    <button type="submit">Найти</button>
                    <button type="button" onclick="clearSearch()">Сбросить</button>
                </div>
            </form>
            
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lastName'])) {
                include 'search_results.php';
            }
            ?>
        </div>
        <?php endif; ?>

        <!-- Страница входа -->
        <div id="login" class="page">
            <h1>🌸 Вход в систему</h1>
            
            <form class="login-form" method="POST" action="login.php">
                <div class="form-group">
                    <label for="username">Логин:</label>
                    <input type="text" id="username" name="username" placeholder="Введите логин" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" name="password" placeholder="Введите пароль" required>
                </div>
                
                <div class="form-group">
                    <button type="submit">Войти</button>
                </div>
            </form>
            
            <?php if (isset($_GET['error'])): ?>
            <div class="message error">
                <?php 
                $errors = [
                    'invalid' => 'Неверный логин или пароль!',
                    'nopermission' => 'У вас нет прав для доступа к системе!'
                ];
                echo $errors[$_GET['error']] ?? 'Произошла ошибка!';
                ?>
            </div>
            <?php endif; ?>
            
            <div style="margin-top: 20px; padding: 15px; background: rgba(255, 182, 193, 0.1); border-radius: 10px;">
                <p><strong>Тестовые учетные данные:</strong></p>
                <ul style="margin-left: 20px;">
                    <li>Логин: <code>user1</code>, Пароль: <code>password123</code> (доступ к поиску)</li>
                    <li>Логин: <code>user2</code>, Пароль: <code>password123</code> (без доступа к поиску)</li>
                    <li>Логин: <code>admin</code>, Пароль: <code>password123</code> (администратор)</li>
                </ul>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <p>🌸 Телефонный справочник &copy; 2025. Все права защищены.</p>
        </div>
    </footer>

    <script>
        function showPage(pageId) {
            const pages = document.querySelectorAll('.page');
            pages.forEach(page => {
                page.classList.remove('active');
            });
            document.getElementById(pageId).classList.add('active');
        }

        function clearSearch() {
            document.querySelector('.search-form').reset();
        }
    </script>
</body>
</html>