<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || !$_SESSION['can_search']) {
    header('Location: index.php?error=nopermission');
    exit;
}

// Логика поиска будет в search_results.php
header('Location: index.php');
exit;
?>